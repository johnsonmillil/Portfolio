# Team-04

FALL 2023
CIS 4375-12371

Startup:
1- Install packages (npm install) in both 'team-04', and 'backend' folders
2- run npm run server in the backend terminal
3- run npm run dev in the front terminal

NEW Startup 
Make sure to run "npm run build" in frontend
In the back end folder, run: "node server.js"
